package edu.wustl.common.datahandler;


public enum HandlerTypeEnum 
{
	TEXT, CSV
};
